##	
	Programa Agenda Estado de animo

## Color descriptions
* Yellow: 0 - 5 appointments
* Orange: 5 - 10 appointments
* Red: > 10 appointments
* Green: current day
* Blue: active day

 
